import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './components/AuthProvider';
import { Toaster } from './components/ui/sonner';
import MainLayout from './components/layout/MainLayout';
import HomePage from './pages/HomePage';
import MatchesPage from './pages/MatchesPage';
import MatchRoomPage from './pages/MatchRoomPage';
import ProfilePage from './pages/ProfilePage';
import SensitivityHubPage from './pages/SensitivityHubPage';
import AuthPage from './pages/AuthPage';
import TeamFinderPage from './pages/TeamFinderPage';
import { useAuthStore } from './store/useAuthStore';

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { isAuthenticated, profile } = useAuthStore();
  
  if (!isAuthenticated) return <Navigate to="/auth" replace />;
  if (isAuthenticated && !profile) return <Navigate to="/profile/setup" replace />;
  
  return <>{children}</>;
}

function SetupProfileRoute({ children }: { children: React.ReactNode }) {
  const { isAuthenticated, profile } = useAuthStore();
  
  if (!isAuthenticated) return <Navigate to="/auth" replace />;
  if (profile) return <Navigate to="/" replace />;
  
  return <>{children}</>;
}

export default function App() {
  return (
    <Router>
      <AuthProvider>
        <Routes>
          <Route path="/auth" element={<AuthPage />} />
          <Route path="/profile/setup" element={<SetupProfileRoute><ProfilePage setup /></SetupProfileRoute>} />
          
          <Route path="/" element={<ProtectedRoute><MainLayout /></ProtectedRoute>}>
            <Route index element={<HomePage />} />
            <Route path="matches" element={<MatchesPage />} />
            <Route path="matches/:matchId" element={<MatchRoomPage />} />
            <Route path="team-finder" element={<TeamFinderPage />} />
            <Route path="sensitivities" element={<SensitivityHubPage />} />
            <Route path="profile" element={<ProfilePage />} />
          </Route>
        </Routes>
        <Toaster theme="dark" />
      </AuthProvider>
    </Router>
  );
}
