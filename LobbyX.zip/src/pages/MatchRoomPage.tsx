import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { doc, getDoc, collection, query, orderBy, onSnapshot, addDoc, serverTimestamp, updateDoc } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../services/firebase';
import { useAuthStore } from '../store/useAuthStore';
import { Match, Message, UserProfile } from '../types';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Badge } from '../components/ui/badge';
import { ScrollArea } from '../components/ui/scroll-area';
import { Send, Copy, ArrowLeft, Gamepad } from 'lucide-react';
import { toast } from 'sonner';

export default function MatchRoomPage() {
  const { matchId } = useParams();
  const { user } = useAuthStore();
  const navigate = useNavigate();
  
  const [match, setMatch] = useState<Match | null>(null);
  const [players, setPlayers] = useState<UserProfile[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  
  const scrollRef = useRef<HTMLDivElement>(null);

  // Fetch Match and Messages
  useEffect(() => {
    if (!matchId) return;

    // Sub to match document
    const matchUnsub = onSnapshot(doc(db, 'matches', matchId), async (docSnap) => {
      if (docSnap.exists()) {
        const matchData = { id: docSnap.id, ...docSnap.data() } as Match;
        setMatch(matchData);
        
        // Fetch player profiles
        try {
          const profiles = await Promise.all(
            matchData.players.map(async (uid) => {
              const pDoc = await getDoc(doc(db, 'users', uid));
              return { id: pDoc.id, ...pDoc.data() } as UserProfile;
            })
          );
          setPlayers(profiles.filter(Boolean));
        } catch (err) {
          console.error('Failed to parse profiles', err);
        }

      } else {
        toast.error('Match not found');
        navigate('/matches');
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, `matches/${matchId}`);
    });

    // Sub to chat messages
    const qMessage = query(
      collection(db, 'matches', matchId, 'messages'),
      orderBy('createdAt', 'asc')
    );
    const messagesUnsub = onSnapshot(qMessage, (snapshot) => {
      const msgs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Message));
      setMessages(msgs);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, `matches/${matchId}/messages`);
    });

    return () => {
      matchUnsub();
      messagesUnsub();
    };
  }, [matchId, navigate]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim() || !user || !matchId) return;

    try {
      await addDoc(collection(db, 'matches', matchId, 'messages'), {
        senderId: user.uid,
        text: newMessage,
        createdAt: serverTimestamp()
      });
      setNewMessage('');
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, `matches/${matchId}/messages`);
      toast.error('Failed to send message');
    }
  };

  const handleStartMatch = async () => {
    if (!matchId || match?.hostId !== user?.uid) return;
    try {
      await updateDoc(doc(db, 'matches', matchId), { status: 'Started' });
      toast.success('Match Started!');
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `matches/${matchId}`);
    }
  };

  const submitMatchResult = async (result: 'Win' | 'Loss') => {
    if (!matchId || !user || !match) return;
    
    try {
      const isHost = match.hostId === user.uid;
      const matchRef = doc(db, 'matches', matchId);
      
      const updatePayload: any = isHost ? { hostResult: result } : { guestResult: result };
      
      // Determine what the match status will be after this update
      const currentHostResult = isHost ? result : match.hostResult;
      const currentGuestResult = isHost ? match.guestResult : result;
      
      if (currentHostResult && currentGuestResult) {
        if (currentHostResult !== currentGuestResult) {
          // Both claim Win, or both claim Loss (mismatch in 1v1 typically they should be opposite, 
          // wait, matchResult should represent the team's outcome? 
          // ELO/Win usually implies Host won and Guest lost or vice versa. 
          // If both submit 'Win', they both claim they won.
          updatePayload.status = 'Disputed';
          toast.error('Result disputed! Both players submitted mismatched results.');
        } else {
          // If both submit the same result, they agree who won? Wait.
          // If I press "WE WON", and the other presses "WE LOST", 
          // then hostResult='Win' and guestResult='Loss'.
          // Then if hostResult !== guestResult, it means they agree!
          // Wait: 
          // If host says "WE WON" (hostResult = Win)
          // Guest says "WE LOST" (guestResult = Loss)
          // -> Agreement
          if (currentHostResult !== currentGuestResult) {
             updatePayload.status = 'Finished';
             
             // Update stats for both players based on the agreed result
             for (const playerId of match.players) {
                const playerIsHost = playerId === match.hostId;
                const playerResult = playerIsHost ? currentHostResult : currentGuestResult;
                const isPlayerWin = playerResult === 'Win';
                
                const userRef = doc(db, 'users', playerId);
                const userDoc = await getDoc(userRef);
                if (userDoc.exists()) {
                  const uData = userDoc.data();
                  // Simple ELO calc: 
                  let newElo = uData.eloRating || 1000;
                  const eloChange = 25; // fixed change for simplicity
                  newElo = isPlayerWin ? newElo + eloChange : newElo - eloChange;
                  
                  await updateDoc(userRef, {
                    totalMatches: (uData.totalMatches || 0) + 1,
                    matchesWon: (uData.matchesWon || 0) + (isPlayerWin ? 1 : 0),
                    matchesLost: (uData.matchesLost || 0) + (isPlayerWin ? 0 : 1),
                    eloRating: Math.max(0, newElo),
                    winStreak: isPlayerWin ? (uData.winStreak || 0) + 1 : 0,
                  });
                }
             }
             toast.success('Match results confirmed by both players!');
          } else {
             // Both said 'Win' or both said 'Loss' -> Disputed
             updatePayload.status = 'Disputed';
             toast.error('Results disputed. Both players submitted conflicting outcomes.');
          }
        }
      } else {
        toast.info('Result submitted. Waiting for opponent to confirm...');
      }

      await updateDoc(matchRef, updatePayload);
      
      if (updatePayload.status === 'Finished') {
        const { setProfile, profile } = useAuthStore.getState();
        if (profile && profile.id === user.uid) {
           // We just let the profile refetch ideally, but for now we could just let them go to profile.
           navigate('/profile?tab=info'); 
        }
      }
      
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `matches/${matchId}`);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success('BGMI ID copied!');
  };

  if (!match) return <div>Loading lobby...</div>;

  const isHost = match.hostId === user?.uid;

  return (
    <div className="h-full flex flex-col pt-4 sm:pt-0">
      <Button variant="ghost" className="self-start mb-4 text-xs font-bold tracking-widest uppercase hover:bg-white/5" onClick={() => navigate('/matches')}>
        <ArrowLeft className="w-4 h-4 mr-2" /> Back to Lobby List
      </Button>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 h-full min-h-0">
        
        {/* Players Sidebar */}
        <div className="md:col-span-1 space-y-4">
          <div className="border border-white/5 bg-[#0a0a0c]/80 backdrop-blur rounded-2xl overflow-hidden flex flex-col">
            <div className="px-5 py-4 border-b border-white/5 bg-white/5 flex flex-col gap-2">
               <div className="flex justify-between items-center">
                 <h3 className="text-xs font-bold uppercase tracking-widest text-primary flex items-center gap-2">
                   {match.type} Lobby
                 </h3>
                 <span className={`text-[10px] uppercase font-bold tracking-widest px-2 py-0.5 rounded border ${match.status === 'Waiting' ? 'border-green-500/30 text-green-400 bg-green-500/10' : 'border-red-500/30 text-red-400 bg-red-500/10'}`}>
                   {match.status}
                 </span>
               </div>
               <p className="text-[10px] uppercase font-bold tracking-widest text-muted-foreground">Weapon: <span className="text-white">{match.weapon}</span></p>
            </div>
            <div className="p-0 divide-y divide-white/5">
              {players.map(p => (
                <div key={p.id} className="p-4 bg-white/[0.02] flex flex-col space-y-2">
                  <div className="flex justify-between items-start">
                    <div>
                      <div className="font-bold text-sm tracking-wide flex items-center gap-2">
                        {p.username}
                        {p.id === match.hostId && <span className="text-[9px] px-1.5 py-0.5 bg-yellow-500/10 text-yellow-500 rounded border border-yellow-500/20 font-black tracking-widest uppercase">HOST</span>}
                      </div>
                      <p className="text-[10px] text-muted-foreground uppercase font-semibold tracking-wider mt-1">{p.tier} • {p.device}</p>
                    </div>
                    <div className="bg-white/5 border border-white/10 rounded px-2 py-1 text-[10px] font-mono flex items-center gap-1 cursor-pointer hover:bg-white/10 transition" onClick={() => copyToClipboard(p.bgmiId)}>
                      <span>{p.bgmiId || 'No ID'}</span>
                      <Copy className="w-3 h-3 text-muted-foreground" />
                    </div>
                  </div>
                </div>
              ))}
              
              {players.length < match.maxPlayers && (
                <div className="p-6 text-center text-muted-foreground animate-pulse flex flex-col items-center gap-3 bg-white/[0.01]">
                  <div className="w-10 h-10 rounded-full border-2 border-dashed border-muted-foreground/30 flex items-center justify-center">
                    <span className="text-lg">+</span>
                  </div>
                  <span className="text-xs font-medium uppercase tracking-widest text-muted-foreground/70">Awaiting {match.maxPlayers - players.length} player(s)</span>
                </div>
              )}
            </div>
            
            {isHost && match.status === 'Waiting' && (
              <div className="p-4 bg-[#0a0a0c] border-t border-white/5">
                <Button className="w-full text-xs font-bold uppercase tracking-widest shadow-[0_0_15px_rgba(239,68,68,0.4)]" size="lg" onClick={handleStartMatch}>
                   START MATCH
                </Button>
              </div>
            )}
            
            {match.status === 'Started' && match.players.includes(user?.uid || '') && (
              <div className="p-4 bg-[#0a0a0c] border-t border-white/5 space-y-3">
                <p className="text-[10px] uppercase font-bold text-muted-foreground text-center tracking-widest">Report Result to End Match</p>
                {((isHost && match.hostResult) || (!isHost && match.guestResult)) ? (
                  <div className="text-center text-xs text-yellow-500 font-bold uppercase tracking-widest bg-yellow-500/10 py-2 rounded">
                    Result Submitted. Waiting for opponent...
                  </div>
                ) : (
                  <div className="flex gap-2">
                    <Button className="flex-1 text-xs font-bold uppercase tracking-widest bg-green-600 hover:bg-green-700 shadow-[0_0_15px_rgba(22,163,74,0.4)]" onClick={() => submitMatchResult('Win')}>
                      WE WON
                    </Button>
                    <Button className="flex-1 text-xs font-bold uppercase tracking-widest bg-red-600 hover:bg-red-700 shadow-[0_0_15px_rgba(220,38,38,0.4)]" onClick={() => submitMatchResult('Loss')}>
                      WE LOST
                    </Button>
                  </div>
                )}
              </div>
            )}
            
            {match.status === 'Disputed' && (
              <div className="p-4 bg-red-500/10 border-t border-red-500/30 text-center">
                 <p className="text-xs text-red-500 font-bold uppercase tracking-widest">Result Disputed</p>
                 <p className="text-[10px] text-muted-foreground mt-1">Please contact admin with screenshots for resolution.</p>
              </div>
            )}
          </div>
        </div>

        {/* Chat Area */}
        <div className="md:col-span-2 flex flex-col border border-white/5 bg-[#0a0a0c]/80 backdrop-blur rounded-2xl overflow-hidden max-h-[70vh] md:max-h-full">
          <div className="px-5 py-4 border-b border-white/5 bg-white/5 flex justify-between items-center">
            <h3 className="text-xs font-bold uppercase tracking-widest text-primary flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" /> Live Comms
            </h3>
          </div>
          
          <ScrollArea className="flex-1 p-5">
            <div className="space-y-4">
              {messages.map(msg => {
                const isMe = msg.senderId === user?.uid;
                const sender = players.find(p => p.id === msg.senderId);
                
                return (
                  <div key={msg.id} className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}>
                    {!isMe && <span className="text-[10px] text-muted-foreground/50 uppercase tracking-widest font-bold mb-1 ml-1">{sender?.username || 'Unknown'}</span>}
                    <div className={`px-4 py-2 text-sm rounded max-w-[80%] ${
                      isMe 
                        ? 'bg-primary/20 text-white border border-primary/30 rounded-tr-none' 
                        : 'bg-white/5 text-gray-300 border border-white/10 rounded-tl-none'
                    }`}>
                      {msg.text}
                    </div>
                  </div>
                );
              })}
              <div ref={scrollRef} />
            </div>
          </ScrollArea>

          <div className="p-4 bg-[#0a0a0c] border-t border-white/5 mt-auto">
            <form onSubmit={handleSendMessage} className="flex gap-2 relative items-center">
              <Input 
                value={newMessage} 
                onChange={(e) => setNewMessage(e.target.value)}
                placeholder="Type a message..." 
                className="bg-white/5 border-white/10 pr-12 focus-visible:ring-primary/50 text-sm"
              />
              <button disabled={!newMessage.trim()} type="submit" className="absolute right-3 text-primary disabled:opacity-50">
                <Send className="w-4 h-4" />
              </button>
            </form>
            <div className="flex gap-2 mt-3 overflow-x-auto pb-1 hide-scrollbar">
              <Button type="button" variant="outline" size="sm" className="h-7 text-[10px] tracking-widest uppercase bg-white/5 border-white/10 shrink-0 hover:bg-white/10 text-muted-foreground" onClick={() => setNewMessage('Send Room ID & Password')}>Need Room ID?</Button>
              <Button type="button" variant="outline" size="sm" className="h-7 text-[10px] tracking-widest uppercase bg-white/5 border-white/10 shrink-0 hover:bg-white/10 text-muted-foreground" onClick={() => setNewMessage('I am ready!')}>I am ready!</Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
