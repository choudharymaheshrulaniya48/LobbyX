import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { doc, getDoc, setDoc, updateDoc, serverTimestamp } from 'firebase/firestore';
import { auth, db, handleFirestoreError, OperationType } from '../services/firebase';
import { useAuthStore } from '../store/useAuthStore';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Textarea } from '../components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { toast } from 'sonner';
import { UserProfile } from '../types';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { UserCircle, Settings2, History, Settings, Info, Mail, Edit3, Crosshair, MonitorSmartphone, Trophy, Target, Swords, Skull, Flame, Gamepad2, BadgePercent, Instagram, Youtube } from 'lucide-react';

export default function ProfilePage({ setup = false }: { setup?: boolean }) {
  const navigate = useNavigate();
  const location = useLocation();
  const { user, profile, setProfile } = useAuthStore();
  const [isLoading, setIsLoading] = useState(false);
  const [isEditing, setIsEditing] = useState(setup);

  const [activeTab, setActiveTab] = useState('info');
  const [matchHistory, setMatchHistory] = useState<Match[]>([]);
  const [loadingHistory, setLoadingHistory] = useState(false);

  const [formData, setFormData] = useState({
    username: '',
    bgmiId: '',
    tier: '',
    kdRatio: '',
    playStyle: '',
    device: '',
    isGyro: 'true',
    bio: ''
  });

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const tabParam = params.get('tab');
    if (tabParam) {
      setActiveTab(tabParam);
      if (tabParam === 'edit') setIsEditing(true);
    }
  }, [location]);

  useEffect(() => {
    let unsubscribe: () => void;
    if (activeTab === 'history' && user) {
      setLoadingHistory(true);
      import('firebase/firestore').then(({ collection, query, where, onSnapshot }) => {
        const q = query(
          collection(db, 'matches'),
          where('players', 'array-contains', user.uid)
        );
        unsubscribe = onSnapshot(q, (snapshot) => {
          const matches = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Match));
          matches.sort((a,b) => b.createdAt - a.createdAt);
          setMatchHistory(matches);
          setLoadingHistory(false);
        }, (error) => {
          console.error(error);
          setLoadingHistory(false);
        });
      });
    }
    return () => {
      if (unsubscribe) unsubscribe();
    };
  }, [activeTab, user]);

  useEffect(() => {
    if (profile && !setup) {
      setFormData({
        username: profile.username || '',
        bgmiId: profile.bgmiId || '',
        tier: profile.tier || '',
        kdRatio: profile.kdRatio || '',
        playStyle: profile.playStyle || '',
        device: profile.device || '',
        isGyro: profile.isGyro ? 'true' : 'false',
        bio: profile.bio || ''
      });
    }
  }, [profile, setup]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    
    setIsLoading(true);
    try {
      const userRef = doc(db, 'users', user.uid);
      const dataToSave = {
        ...formData,
        isGyro: formData.isGyro === 'true',
      };

      if (setup) {
        if (!formData.username || formData.username.length > 30) {
           throw new Error("Username must be between 1 and 30 characters");
        }

        const newProfile = {
          ...dataToSave,
          reputation: 100,
          createdAt: serverTimestamp(),
        };
        await setDoc(userRef, newProfile);
        
        const newDoc = await getDoc(userRef);
        setProfile({ id: newDoc.id, ...newDoc.data() } as UserProfile);
        
        toast.success('Profile created successfully!');
        navigate('/');
      } else {
        await updateDoc(userRef, dataToSave);
        setProfile({ ...profile, ...dataToSave } as UserProfile);
        toast.success('Profile updated successfully!');
        setIsEditing(false);
      }
    } catch (error) {
      handleFirestoreError(error, setup ? OperationType.CREATE : OperationType.UPDATE, `users`);
      toast.error('Failed to save profile');
    } finally {
      setIsLoading(false);
    }
  };

  const onTabChange = (val: string) => {
    setActiveTab(val);
    navigate(`/profile?tab=${val}`, { replace: true });
    if (val === 'edit') setIsEditing(true);
    else setIsEditing(false);
  };

  const renderEditForm = () => (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label htmlFor="username" className="text-[10px] uppercase tracking-wider text-muted-foreground font-bold">Username (In-Game Name)</Label>
          <Input id="username" placeholder="e.g. Mortal, Dynamo" value={formData.username} onChange={(e) => setFormData({...formData, username: e.target.value})} required maxLength={30} className="bg-white/5 border-white/10" />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="bgmiId" className="text-[10px] uppercase tracking-wider text-muted-foreground font-bold">BGMI Character ID</Label>
          <Input id="bgmiId" placeholder="e.g. 5123456789" value={formData.bgmiId} onChange={(e) => setFormData({...formData, bgmiId: e.target.value.replace(/\D/g, '')})} className="bg-white/5 border-white/10" pattern="\d*" title="Only numbers are allowed" />
        </div>

        <div className="space-y-2">
          <Label htmlFor="tier" className="text-[10px] uppercase tracking-wider text-muted-foreground font-bold">Current Tier</Label>
          <Select value={formData.tier} onValueChange={(val) => setFormData({...formData, tier: val})}>
            <SelectTrigger id="tier" className="bg-white/5 border-white/10"><SelectValue placeholder="Select Tier" /></SelectTrigger>
            <SelectContent className="bg-[#0a0a0c] border-white/10">
              <SelectItem value="Bronze">Bronze</SelectItem>
              <SelectItem value="Silver">Silver</SelectItem>
              <SelectItem value="Gold">Gold</SelectItem>
              <SelectItem value="Platinum">Platinum</SelectItem>
              <SelectItem value="Diamond">Diamond</SelectItem>
              <SelectItem value="Crown">Crown</SelectItem>
              <SelectItem value="Ace">Ace</SelectItem>
              <SelectItem value="Ace Master">Ace Master</SelectItem>
              <SelectItem value="Ace Dominator">Ace Dominator</SelectItem>
              <SelectItem value="Conqueror">Conqueror</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="kdRatio" className="text-[10px] uppercase tracking-wider text-muted-foreground font-bold">F/D (K/D) Ratio</Label>
          <Input id="kdRatio" placeholder="e.g. 4.5" value={formData.kdRatio} onChange={(e) => setFormData({...formData, kdRatio: e.target.value})} className="bg-white/5 border-white/10" />
        </div>

        <div className="space-y-2">
          <Label htmlFor="playStyle" className="text-[10px] uppercase tracking-wider text-muted-foreground font-bold">Role / Play Style</Label>
          <Select value={formData.playStyle} onValueChange={(val) => setFormData({...formData, playStyle: val})}>
            <SelectTrigger id="playStyle" className="bg-white/5 border-white/10"><SelectValue placeholder="Select Role" /></SelectTrigger>
            <SelectContent className="bg-[#0a0a0c] border-white/10">
              <SelectItem value="Rush">Assaulter (Rush)</SelectItem>
              <SelectItem value="Sniper">Sniper</SelectItem>
              <SelectItem value="Support">Support</SelectItem>
              <SelectItem value="IGL">IGL</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="device" className="text-[10px] uppercase tracking-wider text-muted-foreground font-bold">Device Type</Label>
          <Select value={formData.device} onValueChange={(val) => setFormData({...formData, device: val})}>
            <SelectTrigger id="device" className="bg-white/5 border-white/10"><SelectValue placeholder="Select Device" /></SelectTrigger>
            <SelectContent className="bg-[#0a0a0c] border-white/10">
              <SelectItem value="Low-end">Low-end Android</SelectItem>
              <SelectItem value="Mid-range">Mid-range Android</SelectItem>
              <SelectItem value="High-end (iPhone/iPad)">High-end (iPhone / iPad / Premium Android)</SelectItem>
              <SelectItem value="Emulator">Emulator</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="isGyro" className="text-[10px] uppercase tracking-wider text-muted-foreground font-bold">Gyroscope player?</Label>
          <Select value={formData.isGyro} onValueChange={(val) => setFormData({...formData, isGyro: val})}>
            <SelectTrigger id="isGyro" className="bg-white/5 border-white/10"><SelectValue placeholder="Select" /></SelectTrigger>
            <SelectContent className="bg-[#0a0a0c] border-white/10">
              <SelectItem value="true">Yes, Gyro on</SelectItem>
              <SelectItem value="false">No, Non-Gyro</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="bio" className="text-[10px] uppercase tracking-wider text-muted-foreground font-bold">Bio</Label>
        <Textarea id="bio" placeholder="Tell others about your playstyle, timings, or goals..." value={formData.bio} onChange={(e) => setFormData({...formData, bio: e.target.value})} className="resize-none bg-white/5 border-white/10" rows={3} />
      </div>

      <div className="flex justify-end pt-4">
        <Button type="submit" className="h-12 w-full md:w-auto px-10 text-xs uppercase tracking-widest font-bold bg-[#FF2E2E] hover:bg-[#FF2E2E]/90 text-white shadow-[0_0_15px_rgba(255,46,46,0.3)]" disabled={isLoading}>
          {isLoading ? 'SAVING...' : (setup ? 'COMPLETE SETUP' : 'SAVE CHANGES')}
        </Button>
      </div>
    </form>
  );

  const renderProfileInfo = () => (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row gap-6 items-start">
        <div className="w-32 h-32 rounded-2xl border-4 border-white/5 bg-[#1A1A1A] flex items-center justify-center shrink-0 shadow-2xl relative overflow-hidden group">
           <span className="font-black text-6xl text-white opacity-80">{profile?.username?.charAt(0).toUpperCase() || 'U'}</span>
           <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex items-end justify-center pb-2 opacity-0 group-hover:opacity-100 transition-opacity">
             <span className="text-[10px] font-bold tracking-widest text-[#FF2E2E] uppercase">Level {Math.floor((profile?.reputation || 100)/10)}</span>
           </div>
        </div>
        <div className="flex-1 space-y-4">
          <div className="flex justify-between items-start">
            <div>
              <h2 className="text-3xl font-black uppercase tracking-wider text-white">{profile?.username || 'Unknown Player'}</h2>
              <div className="flex items-center gap-3 mt-1">
                <span className="text-xs font-mono text-gray-400 bg-white/5 px-2 py-1 rounded">ID: {profile?.bgmiId || 'Not Set'}</span>
                <span className="rank-pill">{profile?.tier || 'Unranked'}</span>
              </div>
            </div>
            <Button onClick={() => onTabChange('edit')} size="sm" className="bg-white/10 hover:bg-white/20 text-white font-bold text-xs uppercase tracking-widest gap-2">
              <Edit3 className="w-3 h-3" /> Edit Mode
            </Button>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 mt-8">
            <div className="glass p-4 rounded-xl border border-white/5 border-l-2 border-l-white">
              <div className="flex items-center gap-2 mb-1">
                <Gamepad2 className="w-4 h-4 text-gray-400" />
                <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">Total Matches</p>
              </div>
              <p className="text-2xl font-black text-white">{profile?.totalMatches || 0}</p>
            </div>
            
            <div className="glass p-4 rounded-xl border border-white/5 border-l-2 border-l-green-500">
              <div className="flex items-center gap-2 mb-1">
                <Trophy className="w-4 h-4 text-green-500" />
                <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">Matches Won</p>
              </div>
              <p className="text-2xl font-black text-white">{profile?.matchesWon || 0}</p>
            </div>
            
            <div className="glass p-4 rounded-xl border border-white/5 border-l-2 border-l-red-500">
              <div className="flex items-center gap-2 mb-1">
                <Skull className="w-4 h-4 text-red-500" />
                <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">Matches Lost</p>
              </div>
              <p className="text-2xl font-black text-white">{profile?.matchesLost || 0}</p>
            </div>
            
            <div className="glass p-4 rounded-xl border border-white/5 border-l-2 border-l-purple-500">
              <div className="flex items-center gap-2 mb-1">
                <BadgePercent className="w-4 h-4 text-purple-500" />
                <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">Win Rate</p>
              </div>
              <p className="text-2xl font-black text-white">{profile?.totalMatches ? Math.round(((profile?.matchesWon || 0) / profile.totalMatches) * 100) : 0}%</p>
            </div>

            <div className="glass p-4 rounded-xl border border-white/5 border-l-2 border-l-[#FF2E2E]">
              <div className="flex items-center gap-2 mb-1">
                <Target className="w-4 h-4 text-[#FF2E2E]" />
                <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">K/D Ratio</p>
              </div>
              <p className="text-2xl font-black text-white">{profile?.kdRatio || '-'}</p>
            </div>

            <div className="glass p-4 rounded-xl border border-white/5 border-l-2 border-l-cyan-500">
               <div className="flex items-center gap-2 mb-1">
                <Swords className="w-4 h-4 text-cyan-500" />
                <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">Role</p>
              </div>
              <p className="text-lg font-bold text-white uppercase">{profile?.playStyle || '-'}</p>
            </div>

            <div className="glass p-4 rounded-xl border border-white/5 border-l-2 border-l-yellow-500">
               <div className="flex items-center gap-2 mb-1">
                <Flame className="w-4 h-4 text-yellow-500" />
                <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">Reputation</p>
              </div>
              <p className="text-2xl font-black text-white">{profile?.reputation || 100}</p>
            </div>

            <div className="glass p-4 rounded-xl border border-white/5 border-l-2 border-l-blue-500">
               <div className="flex items-center gap-2 mb-1">
                <MonitorSmartphone className="w-4 h-4 text-blue-500" />
                <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">Device</p>
              </div>
              <p className="text-sm font-bold text-white">
                {profile?.isGyro ? 'Gyro On' : 'Gyro Off'}
              </p>
            </div>
          </div>
        </div>
      </div>
      
      {profile?.bio && (
        <div className="glass p-5 rounded-xl border border-white/5 mt-6">
          <h3 className="text-xs font-bold uppercase tracking-widest text-[#FF2E2E] mb-2 flex items-center gap-2">
            <UserCircle className="w-4 h-4" /> About Player
          </h3>
          <p className="text-sm text-gray-300 leading-relaxed font-medium">{profile.bio}</p>
        </div>
      )}
    </div>
  );

  return (
    <div className="max-w-5xl mx-auto py-4">
      {setup ? (
         <Card className="border-primary/20 shadow-lg glass bg-[#0a0a0c]">
          <CardHeader>
            <CardTitle className="text-3xl font-black uppercase tracking-wider">Setup Your Profile</CardTitle>
            <CardDescription className="text-xs font-medium uppercase tracking-widest text-muted-foreground mt-2">
              Complete your profile to start finding matches and teammates.
            </CardDescription>
          </CardHeader>
          <CardContent>
             {renderEditForm()}
          </CardContent>
         </Card>
      ) : (
        <Tabs value={activeTab} onValueChange={onTabChange} className="space-y-6">
          <TabsContent value="info">
            {renderProfileInfo()}
          </TabsContent>

          <TabsContent value="edit">
            <Card className="glass border-white/10 bg-[#0a0a0c] p-6 animate-in fade-in zoom-in-95 duration-300">
               <div className="flex justify-between items-center mb-6">
                 <div>
                   <h2 className="text-xl font-black uppercase tracking-wider">Edit Profile</h2>
                   <p className="text-xs text-muted-foreground uppercase tracking-widest font-bold mt-1">Update your combat identity</p>
                 </div>
                 <Button onClick={() => onTabChange('info')} variant="ghost" size="sm" className="text-xs font-bold uppercase tracking-widest">
                   Cancel Edit
                 </Button>
               </div>
               {renderEditForm()}
            </Card>
          </TabsContent>

          <TabsContent value="history">
            <div className="space-y-6 animate-in fade-in duration-500">
               <div className="flex items-center gap-3 border-b border-white/5 pb-4">
                 <History className="w-6 h-6 text-[#FF2E2E]" />
                 <h3 className="text-xl font-black text-white uppercase tracking-wider">Match History</h3>
               </div>
               
               <div className="space-y-4">
                 {loadingHistory ? (
                    <div className="text-center py-10 text-muted-foreground animate-pulse">Loading matches...</div>
                 ) : matchHistory.length === 0 ? (
                   <div className="glass p-12 text-center rounded-xl border border-white/5 border-dashed flex flex-col items-center justify-center">
                     <History className="w-12 h-12 text-muted-foreground/30 mb-4" />
                     <h3 className="text-xl font-bold text-muted-foreground">No matches played yet</h3>
                     <p className="text-xs text-muted-foreground/70 mt-2">Join or create a lobby to start playing</p>
                   </div>
                 ) : (
                   matchHistory.map(match => {
                     const isHost = match.hostId === user?.uid;
                     const result = isHost ? match.hostResult : match.guestResult;
                     const isWin = result === 'Win';
                     const isLoss = result === 'Loss';
                     return (
                       <div key={match.id} className="glass p-4 rounded-xl border border-white/5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:border-white/10 transition-colors">
                         <div className="flex flex-col gap-1">
                           <span className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">
                             {new Date(match.createdAt).toLocaleDateString()}
                           </span>
                           <div className="flex items-center gap-2">
                             <span className="text-white font-bold text-lg">{match.type} Match</span>
                             <span className="text-xs bg-white/10 text-gray-300 px-2 py-0.5 rounded font-medium">{match.status}</span>
                             {match.status === 'Disputed' && (
                                <span className="text-xs bg-yellow-500/10 text-yellow-500 px-2 py-0.5 rounded font-bold border border-yellow-500/20">Disputed</span>
                             )}
                           </div>
                         </div>
                         <div className="flex items-center gap-6">
                           <div className="text-center">
                             <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">Weapon</p>
                             <p className="text-white font-black text-sm uppercase">{match.weapon}</p>
                           </div>
                           {match.status === 'Finished' && result && (
                             <div className={`px-4 py-2 rounded-lg font-black uppercase tracking-widest text-sm w-24 text-center ${
                               isWin ? 'bg-green-500/10 border border-green-500/20 text-green-500' : 'bg-red-500/10 border border-red-500/20 text-red-500'
                             }`}>
                               {result}
                             </div>
                           )}
                           {match.status === 'Finished' && !result && (
                             <div className="bg-white/5 text-muted-foreground px-4 py-2 rounded-lg font-bold uppercase tracking-widest text-xs w-24 text-center">
                               No Result
                             </div>
                           )}
                         </div>
                       </div>
                     );
                   })
                 )}
               </div>
            </div>
          </TabsContent>


          <TabsContent value="about">
            <div className="max-w-2xl mx-auto glass p-8 rounded-xl border-white/5 animate-in fade-in duration-500 space-y-6 text-center">
                <div className="w-20 h-20 bg-[#FF2E2E]/10 rounded-full flex items-center justify-center mx-auto shadow-[0_0_30px_rgba(255,46,46,0.2)]">
                  <span className="text-3xl font-black text-[#FF2E2E]">M</span>
                </div>
                <div>
                  <h3 className="text-2xl font-black text-white uppercase tracking-wider">LobbyX</h3>
                </div>
                <div className="space-y-2">
                  <p className="text-lg text-gray-300 font-medium leading-relaxed">
                    LobbyX is built for gamers who love real competition and real connections.
                  </p>
                  <p className="text-sm text-gray-400 leading-relaxed mt-4">
                    This platform is designed to help BGMI players find teammates, challenge opponents, and improve their gameplay through shared strategies, sensitivities, and experience.
                  </p>
                  <p className="text-sm text-gray-400 leading-relaxed mt-2">
                    Whether you're a rusher, sniper, or IGL — LobbyX gives you the perfect space to connect, compete, and grow.
                  </p>
                  <div className="bg-white/5 border border-white/10 p-4 rounded-lg my-6">
                    <p className="text-white font-bold tracking-wide uppercase text-sm">No paid matches. No pressure. Just pure gaming and fun.</p>
                  </div>
                  <p className="text-sm text-gray-500 italic mt-4">Built with passion for the gaming community.</p>
                  <p className="text-xs text-[#FF2E2E] font-bold uppercase tracking-widest mt-2">— Mahesh Rulaniya</p>
                  
                  <div className="pt-6">
                    <p className="text-xs text-gray-500 font-mono bg-white/5 inline-block px-4 py-1.5 rounded-lg border border-white/10 uppercase font-bold tracking-widest">UID: 5892414503</p>
                  </div>
                </div>
            </div>
          </TabsContent>

          <TabsContent value="contact">
            <div className="max-w-2xl mx-auto glass p-8 rounded-xl border-white/5 animate-in fade-in duration-500 space-y-10">
               <div className="text-center space-y-2">
                 <h3 className="text-3xl font-black text-white uppercase tracking-wider">Contact Me</h3>
                 <p className="text-xs text-muted-foreground uppercase tracking-widest font-bold">Get in touch for collabs or queries</p>
               </div>
               <div className="space-y-4">
                 
                 <a href="https://instagram.com/mahesh.rulaniya.05" target="_blank" rel="noopener noreferrer" className="glass bg-white/5 p-5 rounded-xl border border-white/5 hover:border-pink-500/50 hover:bg-white/10 transition-all flex items-center gap-4 group">
                   <div className="bg-pink-500/20 p-3 rounded-lg group-hover:scale-110 transition-transform duration-300">
                     <Instagram className="w-6 h-6 text-pink-500" />
                   </div>
                   <div>
                     <p className="text-[10px] text-gray-400 uppercase font-bold tracking-widest">Instagram</p>
                     <p className="font-bold text-white text-lg mt-0.5">mahesh.rulaniya.05</p>
                   </div>
                 </a>

                 <a href="https://youtube.com/@SprayzoneYT" target="_blank" rel="noopener noreferrer" className="glass bg-white/5 p-5 rounded-xl border border-white/5 hover:border-red-500/50 hover:bg-white/10 transition-all flex items-center gap-4 group">
                   <div className="bg-red-500/20 p-3 rounded-lg group-hover:scale-110 transition-transform duration-300">
                     <Youtube className="w-6 h-6 text-red-500" />
                   </div>
                   <div>
                     <p className="text-[10px] text-gray-400 uppercase font-bold tracking-widest">YouTube</p>
                     <p className="font-bold text-white text-lg mt-0.5">Sprayzone YT</p>
                   </div>
                 </a>
                 
                 <a href="mailto:maheshrulaniya2775@gmail.com" className="glass bg-white/5 p-5 rounded-xl border border-white/5 hover:border-blue-500/50 hover:bg-white/10 transition-all flex items-center gap-4 group">
                   <div className="bg-blue-500/20 p-3 rounded-lg group-hover:scale-110 transition-transform duration-300">
                     <Mail className="w-6 h-6 text-blue-500" />
                   </div>
                   <div>
                     <p className="text-[10px] text-gray-400 uppercase font-bold tracking-widest">Email</p>
                     <p className="font-bold text-white text-lg mt-0.5">maheshrulaniya2775@gmail.com</p>
                   </div>
                 </a>

               </div>
            </div>
          </TabsContent>
        </Tabs>
      )}
    </div>
  );
}
