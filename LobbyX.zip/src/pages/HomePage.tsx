import { Link } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../components/ui/card';
import { buttonVariants } from '../components/ui/button';
import { Gamepad2, Users, Flame, Settings2, Trophy, Star } from 'lucide-react';
import { useAuthStore } from '../store/useAuthStore';

export default function HomePage() {
  const { profile } = useAuthStore();

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      
      {/* Hero Welcome */}
      <section className="relative overflow-hidden rounded-2xl glass p-8 md:p-12 mb-8 neon-border-red">
        <div className="absolute -top-24 -right-24 w-96 h-96 bg-primary/10 rounded-full blur-[80px]" />
        <div className="relative z-10 space-y-4">
          <h1 className="text-4xl md:text-5xl font-black uppercase tracking-tight">
            Welcome back, <span className="neon-text-red">{profile?.username || 'Player'}</span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl font-medium">
            Find the perfect teammate. Share your god-tier sensitivities. Dominate the battleground.
          </p>
          <div className="flex flex-wrap gap-4 pt-4">
            <Link to="/matches" className={buttonVariants({ size: "lg", className: "h-14 px-8 text-xs tracking-widest uppercase font-bold bg-primary hover:bg-primary/90 shadow-[0_0_20px_rgba(239,68,68,0.3)]" })}>
              <Gamepad2 className="mr-2" /> Find a Match
            </Link>
            <Link to="/sensitivities" className={buttonVariants({ variant: "outline", size: "lg", className: "h-14 px-8 text-xs tracking-widest uppercase font-bold bg-white/5 border border-white/10 hover:bg-white/10 text-white" })}>
              <Settings2 className="mr-2" /> Explore Sensitivities
            </Link>
          </div>
        </div>
      </section>

      {/* Stats & Quick Links Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        <Card className="glass stat-card hover:bg-white/5 transition-all duration-300 group cursor-pointer border-l-4 border-l-yellow-500">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-sm font-bold uppercase tracking-widest text-muted-foreground">
              <Star className="text-yellow-500 w-4 h-4 group-hover:rotate-180 transition-transform duration-500" /> Reputation
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-4xl font-black text-foreground">{profile?.reputation || 100}</div>
            <p className="text-xs mt-2 text-muted-foreground">Keep playing well to increase it!</p>
          </CardContent>
        </Card>

        <Card className="glass stat-card hover:bg-white/5 transition-all duration-300 border-l-4 border-l-red-500">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-sm font-bold uppercase tracking-widest text-muted-foreground">
              <Flame className="text-red-500 w-4 h-4 animate-pulse" /> Matchmaking
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">Live Now</div>
            <p className="text-xs mt-2 text-muted-foreground mb-4">Players are searching for 1v1 and Squad matches.</p>
            <Link to="/matches" className={buttonVariants({ variant: "secondary", className: "w-full text-xs font-bold bg-red-500/10 text-red-500 hover:bg-red-500 hover:text-white transition" })}>
              Join Lobby
            </Link>
          </CardContent>
        </Card>

        <Card className="glass stat-card hover:bg-white/5 transition-all duration-300 border-l-4 border-l-cyan-500">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-sm font-bold uppercase tracking-widest text-muted-foreground">
              <Users className="text-cyan-500 w-4 h-4" /> Team Finder
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">Need a Squad?</div>
            <p className="text-xs mt-2 text-muted-foreground mb-4">Find reliable teammates with your play style.</p>
            <Link to="/team-finder" className={buttonVariants({ variant: "secondary", className: "w-full text-xs font-bold bg-cyan-500/10 text-cyan-500 hover:bg-cyan-500 hover:text-white transition" })}>
              Find Teammates
            </Link>
          </CardContent>
        </Card>
      </div>

      {/* Leaderboards Placeholder */}
      <section className="space-y-4 pt-4">
        <h2 className="text-lg font-bold uppercase tracking-widest flex items-center">
          <span className="w-1 h-6 bg-yellow-500 mr-3"></span>
          Top Rated Players
        </h2>
        <Card className="glass rounded-2xl overflow-hidden p-0 border-none">
          <CardContent className="p-0">
             <div className="divide-y divide-white/5">
                {[1,2,3].map(i => (
                  <div key={i} className="flex items-center justify-between p-5 hover:bg-white/5 transition-colors">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 bg-white/5 border border-white/10 rounded-lg flex items-center justify-center font-bold text-yellow-500">#{i}</div>
                      <div>
                        <p className="text-sm font-bold">ProPlayer_{i}00</p>
                        <p className="text-xs text-muted-foreground uppercase tracking-widest mt-1">Ace Master • Assaulter</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-1 text-yellow-500 font-bold bg-yellow-500/10 px-3 py-1 rounded-md text-xs">
                      <Star className="w-3 h-3" /> {100 + (10-i)*5}
                    </div>
                  </div>
                ))}
             </div>
          </CardContent>
        </Card>
      </section>

    </div>
  );
}
