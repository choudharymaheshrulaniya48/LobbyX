import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Textarea } from '../components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Users, Search, Plus, Filter, UserPlus } from 'lucide-react';
import { useAuthStore } from '../store/useAuthStore';
import { collection, onSnapshot, addDoc, updateDoc, doc, serverTimestamp, getDocs, query, where, getDoc } from 'firebase/firestore';
import { db } from '../services/firebase';
import { handleFirestoreError, OperationType } from '../services/firebase';
import { toast } from 'sonner';
import { TeamPost, UserProfile } from '../types';

export default function TeamFinderPage() {
  const { profile } = useAuthStore();
  const [posts, setPosts] = useState<(TeamPost & { author?: UserProfile })[]>([]);
  const [isCreating, setIsCreating] = useState(false);
  const [formData, setFormData] = useState({
    roleNeeded: 'Assaulter',
    minKd: '3.0',
    minTier: 'Diamond',
    playStyle: 'Rush',
    mode: 'Squad',
    message: ''
  });

  useEffect(() => {
    // Fetch posts and enrich with author profiles
    const postsQuery = query(collection(db, 'teamPosts'), where('status', '==', 'Open'));
    
    const unsubscribe = onSnapshot(postsQuery, async (snapshot) => {
      try {
        const postsData = snapshot.docs.map(d => ({ id: d.id, ...d.data() } as TeamPost));
        
        // Fetch all authors
        const enrichedPosts = await Promise.all(postsData.map(async (post) => {
          try {
            const authorDoc = await getDoc(doc(db, 'users', post.authorId));
            if (authorDoc.exists()) {
              return { ...post, author: authorDoc.data() as UserProfile };
            }
          } catch(e) {}
          return post;
        }));
        
        setPosts(enrichedPosts.sort((a,b) => b.createdAt - a.createdAt));
      } catch (error) {
        handleFirestoreError(error, OperationType.LIST, 'teamPosts');
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'teamPosts');
    });

    return () => unsubscribe();
  }, []);

  const handleCreatePost = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile) return;
    
    try {
      await addDoc(collection(db, 'teamPosts'), {
        ...formData,
        authorId: profile.id,
        status: 'Open',
        createdAt: Date.now()
      });
      setIsCreating(false);
      toast.success('Team post created successfully!');
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'teamPosts');
    }
  };

  const handleSendRequest = async (postId: string) => {
    if (!profile) return;
    
    try {
      await addDoc(collection(db, 'teamRequests'), {
        postId,
        requesterId: profile.id,
        status: 'Pending',
        createdAt: Date.now()
      });
      toast.success('Request sent successfully!');
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'teamRequests');
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500 max-w-5xl mx-auto">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-black uppercase tracking-widest text-white flex items-center gap-3">
            <Users className="w-8 h-8 text-cyan-500 drop-shadow-[0_0_10px_rgba(6,182,212,0.8)]" />
            Team Finder
          </h1>
          <p className="text-sm text-muted-foreground mt-1 uppercase tracking-widest font-bold">Find the perfect squad base on playstyle</p>
        </div>
        
        <Button 
          onClick={() => setIsCreating(!isCreating)} 
          className="text-xs uppercase tracking-widest font-bold bg-cyan-500 hover:bg-cyan-600 text-white shadow-[0_0_15px_rgba(6,182,212,0.4)]"
        >
          {isCreating ? 'Cancel' : <><Plus className="w-4 h-4 mr-2" /> Post Requirement</>}
        </Button>
      </div>

      {isCreating && (
        <Card className="glass border-cyan-500/30 shadow-[0_0_20px_rgba(6,182,212,0.1)]">
          <CardHeader>
            <CardTitle className="text-sm font-bold uppercase tracking-widest text-cyan-500">Create Team Post</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleCreatePost} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Required Role</Label>
                  <Select value={formData.roleNeeded} onValueChange={(val) => setFormData({...formData, roleNeeded: val})}>
                    <SelectTrigger className="bg-white/5 border-white/10"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Rush">Rush / Assaulter</SelectItem>
                      <SelectItem value="Sniper">Sniper</SelectItem>
                      <SelectItem value="Support">Support</SelectItem>
                      <SelectItem value="IGL">IGL</SelectItem>
                      <SelectItem value="Any">Any Role</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label>Mode</Label>
                  <Select value={formData.mode} onValueChange={(val) => setFormData({...formData, mode: val})}>
                    <SelectTrigger className="bg-white/5 border-white/10"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1v1">1v1 TDM</SelectItem>
                      <SelectItem value="2v2">2v2 TDM / Classic</SelectItem>
                      <SelectItem value="WOW Mode">WOW Mode</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Minimum Tier</Label>
                  <Select value={formData.minTier} onValueChange={(val) => setFormData({...formData, minTier: val})}>
                    <SelectTrigger className="bg-white/5 border-white/10"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Diamond">Diamond</SelectItem>
                      <SelectItem value="Crown">Crown</SelectItem>
                      <SelectItem value="Ace">Ace</SelectItem>
                      <SelectItem value="Ace Master">Ace Master</SelectItem>
                      <SelectItem value="Conqueror">Conqueror</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Minimum K/D</Label>
                  <Input 
                    value={formData.minKd} 
                    onChange={(e) => setFormData({...formData, minKd: e.target.value})}
                    placeholder="e.g. 3.5"
                    className="bg-white/5 border-white/10"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label>Additional Message</Label>
                <Textarea 
                  value={formData.message} 
                  onChange={(e) => setFormData({...formData, message: e.target.value})}
                  placeholder="e.g. Need aggressive players for push to Conqueror..."
                  className="bg-white/5 border-white/10 resize-none h-20"
                />
              </div>

              <div className="flex justify-end pt-2">
                <Button type="submit" className="bg-cyan-500 hover:bg-cyan-600 font-bold uppercase tracking-widest text-xs">Post</Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {posts.length === 0 ? (
          <div className="col-span-full py-12 text-center text-muted-foreground">
            No team posts available right now. Be the first to create one!
          </div>
        ) : (
          posts.map(post => (
            <Card key={post.id} className="glass hover:bg-white/5 transition-colors border-white/5 flex flex-col justify-between">
              <CardContent className="p-6">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="font-bold text-lg text-white">Need <span className="text-cyan-400">{post.roleNeeded}</span></h3>
                    <p className="text-xs text-muted-foreground uppercase tracking-widest">For {post.mode}</p>
                  </div>
                  <div className="px-3 py-1 bg-white/5 rounded text-xs font-bold uppercase border border-white/10">
                    Min {post.minKd} KD • {post.minTier}
                  </div>
                </div>
                
                <p className="text-sm text-gray-300 italic mb-4">"{post.message}"</p>
                
                {post.author && (
                  <div className="flex items-center gap-3 p-3 bg-black/40 rounded-lg border border-white/5 mb-4">
                    <div className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center font-bold text-white shadow-inner">
                      {post.author.username.charAt(0)}
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-bold text-white">{post.author.username}</p>
                      <p className="text-[10px] text-gray-400 uppercase tracking-widest">
                        {post.author.tier} • {post.author.playStyle} • KD: {post.author.kdRatio}
                      </p>
                    </div>
                  </div>
                )}
                
                <Button 
                  onClick={() => handleSendRequest(post.id)}
                  disabled={profile?.id === post.authorId}
                  className="w-full font-bold uppercase tracking-widest text-xs bg-white/10 hover:bg-white/20 text-white"
                >
                  <UserPlus className="w-4 h-4 mr-2" /> Send Request
                </Button>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}
