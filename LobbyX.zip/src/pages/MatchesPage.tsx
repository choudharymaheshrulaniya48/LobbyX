import { useState, useEffect } from 'react';
import { collection, query, orderBy, onSnapshot, addDoc, serverTimestamp, doc, updateDoc, arrayUnion } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../services/firebase';
import { Match, UserProfile } from '../types';
import { useAuthStore } from '../store/useAuthStore';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '../components/ui/dialog';
import { toast } from 'sonner';
import { useNavigate } from 'react-router-dom';
import { MoreVertical, Trash2, Crosshair, Map, Clock } from 'lucide-react';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from '../components/ui/dropdown-menu';
import { deleteDoc } from 'firebase/firestore';
import { formatDistanceToNow } from 'date-fns';

export default function MatchesPage() {
  const { user, profile } = useAuthStore();
  const navigate = useNavigate();
  const [matches, setMatches] = useState<Match[]>([]);
  const [isCreating, setIsCreating] = useState(false);
  
  // Dialog state
  const [matchType, setMatchType] = useState<'1v1' | '2v2' | 'Squad'>('1v1');
  const [minTier, setMinTier] = useState('Any');
  const [weaponCategory, setWeaponCategory] = useState<string>('AR');
  const [selectedWeapon, setSelectedWeapon] = useState<string>('M416');
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [enrichedMatches, setEnrichedMatches] = useState<(Match & { hostProfile?: UserProfile })[]>([]);

  const WEAPONS: Record<string, string[]> = {
    'AR': ['M416', 'AKM', 'SCAR-L', 'M762', 'AUG'],
    'Sniper': ['M24', 'Kar98k'],
    'SMG': ['UMP45', 'Vector', 'UZI', 'P90'],
    'LMG': ['DP-28'],
    'Shotgun': ['S1897', 'S686', 'DBS'],
    'DMR': ['Mini14', 'SKS', 'SLR'],
    'Melee': ['Pan', 'Knife', 'Bat']
  };

  useEffect(() => {
    // Whenever category changes, default to first weapon
    if (WEAPONS[weaponCategory]) {
      setSelectedWeapon(WEAPONS[weaponCategory][0]);
    }
  }, [weaponCategory]);

  useEffect(() => {
    const q = query(
      collection(db, 'matches'),
      orderBy('createdAt', 'desc')
    );

    const unsubscribe = onSnapshot(q, async (snapshot) => {
      try {
        const liveMatches = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Match));
        const activeMatches = liveMatches.filter(m => m.status !== 'Finished');
        
        // Enrich with host profiles for real-time display
        // Note: in a real big app this might be heavy, but it's fine for small scope
        const { getDoc } = await import('firebase/firestore');
        const enriched = await Promise.all(activeMatches.map(async m => {
          try {
             const hostDoc = await getDoc(doc(db, 'users', m.hostId));
             if(hostDoc.exists()) {
               return { ...m, hostProfile: hostDoc.data() as UserProfile };
             }
          } catch(e) {}
          return m;
        }));
        
        setEnrichedMatches(enriched);
      } catch (error) {
        handleFirestoreError(error, OperationType.LIST, 'matches');
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'matches');
    });

    return () => unsubscribe();
  }, []);

  const handleCreateMatch = async () => {
    if (!user || !profile) return;
    setIsCreating(true);
    try {
      const maxPlayers = matchType === '1v1' ? 2 : matchType === '2v2' ? 4 : 4;
      const matchData = {
        hostId: user.uid,
        type: matchType,
        status: 'Waiting',
        maxPlayers,
        players: [user.uid],
        minTier,
        weapon: selectedWeapon,
        createdAt: serverTimestamp(),
      };

      const docRef = await addDoc(collection(db, 'matches'), matchData);
      toast.success('Match created! Waiting for players...');
      setIsDialogOpen(false);
      navigate(`/matches/${docRef.id}`);
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'matches');
      toast.error('Failed to create match');
    } finally {
      setIsCreating(false);
    }
  };

  const handleJoinMatch = async (matchId: string) => {
    if (!user) return;
    try {
      const matchRef = doc(db, 'matches', matchId);
      await updateDoc(matchRef, {
        players: arrayUnion(user.uid),
        // A cloud function or smart client checking should update status to Full if players.length == maxPlayers.
        // For prototyping, we'll let the user join and if they exceed maxPlayers we probably want to block it,
        // but simple arrayUnion is fine for now.
      });
      navigate(`/matches/${matchId}`);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `matches/${matchId}`);
      toast.error('Could not join match');
    }
  };

  const handleDeleteMatch = async (matchId: string) => {
    try {
      await deleteDoc(doc(db, 'matches', matchId));
      toast.success('Lobby deleted successfully');
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `matches/${matchId}`);
      toast.error('Failed to delete lobby');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-lg font-bold uppercase tracking-widest flex items-center">
            <span className="w-1 h-6 bg-red-600 mr-3"></span>
            Live Matchmaking
          </h1>
          <p className="text-xs text-gray-500 font-medium mt-1">Find opponents or teammates in real-time</p>
        </div>
        
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger render={<Button size="lg" className="w-full md:w-auto text-xs font-bold bg-primary hover:bg-primary/90 shadow-[0_0_15px_rgba(239,68,68,0.3)]" />}>
            CREATE LOBBY
          </DialogTrigger>
          <DialogContent className="sm:max-w-[425px] glass border-white/10 text-foreground bg-[#0a0a0c]">
            <DialogHeader>
              <DialogTitle className="text-xl uppercase tracking-widest font-black">Create Match</DialogTitle>
              <DialogDescription className="text-muted-foreground text-xs">
                Set your requirements and wait for players to join.
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="space-y-2">
                <Label className="text-[10px] uppercase tracking-wider text-muted-foreground font-bold">Match Type</Label>
                <Select value={matchType} onValueChange={(val: any) => setMatchType(val)}>
                  <SelectTrigger className="bg-white/5 border-white/10 text-sm"><SelectValue placeholder="Select type" /></SelectTrigger>
                  <SelectContent className="bg-[#0a0a0c] border-white/10">
                    <SelectItem value="1v1">1v1 (TDM Room)</SelectItem>
                    <SelectItem value="2v2">2v2 (TDM Room)</SelectItem>
                    <SelectItem value="Squad">Squad (Classic)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label className="text-[10px] uppercase tracking-wider text-muted-foreground font-bold">Minimum Tier Required</Label>
                <Select value={minTier} onValueChange={setMinTier}>
                  <SelectTrigger className="bg-white/5 border-white/10 text-sm"><SelectValue placeholder="Select Tier" /></SelectTrigger>
                  <SelectContent className="bg-[#0a0a0c] border-white/10">
                    <SelectItem value="Any">Any Tier</SelectItem>
                    <SelectItem value="Diamond">Diamond+</SelectItem>
                    <SelectItem value="Crown">Crown+</SelectItem>
                    <SelectItem value="Ace">Ace+</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-3 pt-2">
                <Label className="text-[10px] uppercase tracking-wider text-muted-foreground font-bold">Select Weapon Category</Label>
                <div className="flex flex-wrap gap-2">
                  {Object.keys(WEAPONS).map(cat => (
                    <button
                      key={cat}
                      className={`px-3 py-1.5 text-xs font-bold uppercase tracking-wider rounded-lg border transition-all ${
                        weaponCategory === cat 
                        ? 'bg-red-600 border-red-500 shadow-[0_0_10px_rgba(220,38,38,0.5)] text-white' 
                        : 'bg-white/5 border-white/10 text-muted-foreground hover:bg-white/10'
                      }`}
                      onClick={() => setWeaponCategory(cat)}
                    >
                      {cat}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-3 pt-2 animate-in fade-in duration-300">
                <Label className="text-[10px] uppercase tracking-wider text-muted-foreground font-bold">Select Gun</Label>
                <div className="grid grid-cols-3 gap-2">
                  {WEAPONS[weaponCategory]?.map(gun => (
                    <button
                      key={gun}
                      className={`py-2 px-1 text-xs font-bold uppercase rounded-lg border transition-all ${
                        selectedWeapon === gun
                        ? 'bg-cyan-600 border-cyan-500 shadow-[0_0_10px_rgba(6,182,212,0.5)] text-white'
                        : 'bg-white/5 border-white/10 text-muted-foreground hover:text-white hover:bg-white/10'
                      }`}
                      onClick={() => setSelectedWeapon(gun)}
                    >
                      {gun}
                    </button>
                  ))}
                </div>
              </div>
            </div>
            <Button onClick={handleCreateMatch} disabled={isCreating} className="w-full text-xs font-bold uppercase tracking-widest bg-primary hover:bg-primary/90">
              {isCreating ? 'CREATING...' : 'LAUNCH LOBBY'}
            </Button>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {enrichedMatches.length === 0 ? (
          <div className="col-span-full py-16 text-center glass rounded-2xl">
            <Crosshair className="w-12 h-12 text-muted-foreground/30 mx-auto mb-4" />
            <h3 className="text-xl font-bold text-muted-foreground">No Live Matches</h3>
            <p className="text-xs text-muted-foreground/70 mt-2">Create a lobby to get started</p>
          </div>
        ) : (
          enrichedMatches.map((match, index) => {
            const isFull = match.players.length >= match.maxPlayers;
            const isHost = match.hostId === user?.uid;
            const isJoined = match.players.includes(user?.uid || '');
            
            const borderColors = ['border-l-red-600', 'border-l-cyan-600', 'border-l-yellow-600', 'border-l-blue-600'];
            const colorClass = borderColors[index % borderColors.length];
            const hostName = match.hostProfile?.username || `Host: ${match.hostId.substring(0,8)}`;
            const hostKd = match.hostProfile?.kdRatio || 'N/A';

            return (
              <div key={match.id} className={`glass p-5 rounded-2xl flex flex-col justify-between hover:bg-white/5 transition border-l-4 ${colorClass} ${match.status === 'Started' ? 'opacity-60' : ''}`}>
                <div className="flex justify-between items-start">
                  <div className="flex items-center space-x-3">
                    <div className="px-3 py-1.5 rounded-lg bg-white/5 flex items-center justify-center font-black text-xs tracking-wider text-primary border border-white/10 uppercase">
                      {match.type} • {match.weapon}
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-white">{hostName}</h3>
                      <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest line-clamp-1">KD: {hostKd}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="rank-pill">{match.minTier}</span>
                    {isHost && (
                      <DropdownMenu>
                        <DropdownMenuTrigger render={
                          <button className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-white/10 transition-colors text-muted-foreground hover:text-white">
                            <MoreVertical className="w-4 h-4" />
                          </button>
                        } />
                        <DropdownMenuContent align="end" className="glass border-white/10 bg-[#0a0a0c]">
                          <DropdownMenuItem 
                            onClick={() => handleDeleteMatch(match.id)}
                            className="text-red-500 hover:text-red-400 hover:bg-red-500/10 cursor-pointer font-bold text-xs uppercase tracking-widest focus:bg-red-500/10 focus:text-red-400"
                          >
                            <Trash2 className="w-4 h-4 mr-2" />
                            Delete Lobby
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    )}
                  </div>
                </div>
                
                <div className="flex items-center mt-6 space-x-6">
                  <div className="text-center">
                    <p className="text-[10px] text-gray-500 uppercase font-bold">Players</p>
                    <p className="text-sm font-bold">{match.players.length}/{match.maxPlayers}</p>
                  </div>
                  <div className="text-center">
                    <p className="text-[10px] text-gray-500 uppercase font-bold">Weapon</p>
                    <p className="text-sm font-bold uppercase">{match.weapon}</p>
                  </div>
                  <div className="text-center text-right flex-1">
                    <p className="text-[10px] text-gray-500 uppercase font-bold">Age</p>
                    <p className="text-[10px] mt-1 font-medium">{match.createdAt ? formatDistanceToNow((match.createdAt as any)?.toDate?.() || Date.now()) : '0m'}</p>
                  </div>
                </div>
                
                <div className="mt-6 flex items-center justify-between">
                  <div className="flex -space-x-2">
                    {Array.from({ length: Math.min(match.players.length, 3) }).map((_, i) => (
                      <div key={i} className="w-8 h-8 rounded-full border-2 border-[#0a0a0c] bg-gray-800" />
                    ))}
                    {match.players.length < match.maxPlayers && (
                      <div className="w-8 h-8 rounded-full border-2 border-[#0a0a0c] border-dashed flex items-center justify-center text-xs text-gray-600 bg-black/40">+</div>
                    )}
                  </div>
                  
                  {isJoined ? (
                    <button className="px-6 py-2 bg-white/10 text-white text-xs font-bold rounded-lg border border-white/20 hover:bg-white/20 transition" onClick={() => navigate(`/matches/${match.id}`)}>
                      ENTER LOBBY
                    </button>
                  ) : match.status === 'Started' ? (
                     <span className="text-[10px] font-bold text-red-500 uppercase tracking-tighter mr-2">Started</span>
                  ) : (
                    <button 
                      className={`px-6 py-2 ${isFull ? 'bg-gray-800 text-gray-500 border border-transparent cursor-not-allowed' : 'bg-red-600/20 text-red-500 border-red-500/30 hover:bg-red-600 hover:text-white'} text-xs font-bold rounded-lg border transition`}
                      onClick={() => handleJoinMatch(match.id)}
                      disabled={isFull}
                    >
                      {isFull ? 'FULL' : 'JOIN ROOM'}
                    </button>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
