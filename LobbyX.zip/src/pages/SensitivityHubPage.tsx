import React, { useState, useEffect } from 'react';
import { collection, query, orderBy, onSnapshot, addDoc, serverTimestamp, doc, updateDoc, increment, deleteDoc, arrayRemove, arrayUnion } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../services/firebase';
import { useAuthStore } from '../store/useAuthStore';
import { Sensitivity } from '../types';
import { Card, CardContent, CardHeader, CardTitle, CardFooter, CardDescription } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '../components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Badge } from '../components/ui/badge';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from '../components/ui/dropdown-menu';
import { Heart, Copy, Smartphone, Cpu, MoreVertical, Trash2 } from 'lucide-react';
import { toast } from 'sonner';

export default function SensitivityHubPage() {
  const { user } = useAuthStore();
  const [sensitivities, setSensitivities] = useState<Sensitivity[]>([]);
  const [filterDevice, setFilterDevice] = useState('All');
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  // Form State
  const [title, setTitle] = useState('');
  const [deviceType, setDeviceType] = useState('Mid-range');
  const [code, setCode] = useState('');
  const [codeError, setCodeError] = useState('');

  const validateNumbersOnly = (val: string) => /^\d*$/.test(val);

  const handleCodeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    if (validateNumbersOnly(val)) {
      setCode(val);
      setCodeError('');
    } else {
      // Keep previous valid code, just show error
      setCodeError('Only numbers are allowed');
    }
  };

  useEffect(() => {
    const q = query(collection(db, 'sensitivities'), orderBy('likes', 'desc'));
    const unsub = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Sensitivity));
      
      // Automatically delete non-numeric codes
      const validData = data.filter(s => {
        if (!/^\d+$/.test(s.code)) {
          // Fire and forget delete
          deleteDoc(doc(db, 'sensitivities', s.id)).catch(err => console.error("Failed auto-delete", err));
          return false;
        }
        return true;
      });

      setSensitivities(validData);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'sensitivities');
    });

    return () => unsub();
  }, []);

  const handleCreateSensitivity = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    
    let valid = true;
    if (!validateNumbersOnly(code) || code.length === 0) {
      setCodeError('Only numbers are allowed');
      valid = false;
    }
    if (!valid) return;

    setIsLoading(true);
    try {
      await addDoc(collection(db, 'sensitivities'), {
        authorId: user.uid,
        title,
        deviceType,
        code,
        likes: 0,
        likedBy: [],
        createdAt: serverTimestamp()
      });
      toast.success('Sensitivity uploaded successfully!');
      setIsDialogOpen(false);
      setTitle(''); setCode('');
      setCodeError('');
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'sensitivities');
      toast.error('Failed to upload sensitivity');
    } finally {
      setIsLoading(false);
    }
  };

  const handleLike = async (id: string, sensitivity: Sensitivity) => {
    if (!user) return;
    try {
        const ref = doc(db, 'sensitivities', id);
        const hasLiked = sensitivity.likedBy?.includes(user.uid);
        
        if (hasLiked) {
            await updateDoc(ref, { 
                likes: increment(-1),
                likedBy: arrayRemove(user.uid)
            });
            toast.success('Like removed');
        } else {
            await updateDoc(ref, { 
                likes: increment(1),
                likedBy: arrayUnion(user.uid)
            });
            toast.success('Liked!');
        }
    } catch (error) {
        handleFirestoreError(error, OperationType.UPDATE, `sensitivities/${id}`);
    }
  };

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    toast.success(`${label} code copied!`);
  };

  const handleDelete = async (id: string) => {
    console.log("Delete triggered for id:", id);
    if (window.confirm("Are you sure you want to delete this sensitivity?")) {
      setDeletingId(id);
      try {
        await deleteDoc(doc(db, 'sensitivities', id));
        console.log("Successfully deleted from database");
        toast.success("Sensitivity deleted successfully");
        // Item is instantly removed from UI because we use onSnapshot for realtime updates from Firebase
      } catch (error) {
        console.error("Failed to delete sensitivity:", error);
        handleFirestoreError(error, OperationType.DELETE, `sensitivities/${id}`);
        setDeletingId(null);
      }
    } else {
      console.log("Delete cancelled by user");
    }
  };

  const filteredSensitivities = filterDevice === 'All' 
    ? sensitivities 
    : sensitivities.filter(s => s.deviceType === filterDevice);

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-black uppercase">Sensitivity Hub</h1>
          <p className="text-muted-foreground">Discover top-rated settings for your device</p>
        </div>
        
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger render={<Button size="lg" className="w-full md:w-auto font-bold shadow-[0_0_15px_rgba(200,30,30,0.5)]" />}>
            Upload Sensitivities
          </DialogTrigger>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>Share your Setup</DialogTitle>
              <DialogDescription>Help the community by sharing your god-tier controls.</DialogDescription>
            </DialogHeader>
            <form onSubmit={handleCreateSensitivity} className="space-y-4 py-4">
              <div className="space-y-2">
                <Label>Title (e.g. My Competitive iPhone Setup)</Label>
                <Input value={title} onChange={e => setTitle(e.target.value)} required />
              </div>
              <div className="space-y-2">
                <Label>Device Type</Label>
                <Select value={deviceType} onValueChange={setDeviceType}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Low-end">Low-end Android</SelectItem>
                    <SelectItem value="Mid-range">Mid-range Android</SelectItem>
                    <SelectItem value="High-end (iPhone/iPad)">High-end / iOS</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2 relative pt-2">
                <Label>Sensitivity Code (Numbers Only)</Label>
                <Input 
                  value={code} 
                  onChange={handleCodeChange} 
                  placeholder="e.g. 712012341234" 
                  required 
                  className={`transition-colors ${codeError ? 'border-red-500 focus-visible:ring-red-500' : ''}`}
                />
                {codeError && <p className="text-[10px] text-red-500 font-bold uppercase tracking-widest absolute -bottom-4 left-0">{codeError}</p>}
              </div>
              <Button type="submit" className="w-full mt-6" disabled={isLoading}>
                {isLoading ? 'Uploading...' : 'Publish'}
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Filters */}
      <div className="flex gap-2 pb-2 overflow-x-auto hide-scrollbar">
        {['All', 'Low-end', 'Mid-range', 'High-end (iPhone/iPad)'].map(device => (
          <Button 
            key={device} 
            variant={filterDevice === device ? 'default' : 'outline'} 
            onClick={() => setFilterDevice(device)}
            className="rounded-full shrink-0"
          >
            {device === 'High-end (iPhone/iPad)' ? <Smartphone className="w-4 h-4 mr-2" /> : <Cpu className="w-4 h-4 mr-2" />}
            {device === 'High-end (iPhone/iPad)' ? 'High-end / iOS' : device}
          </Button>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredSensitivities.length === 0 ? (
           <div className="col-span-full text-center py-12 text-muted-foreground">
             No sensitivities found for this device type.
           </div>
        ) : (
          filteredSensitivities.map((s, index) => (
            <Card key={s.id} className={`relative overflow-hidden bg-card/60 backdrop-blur border-border group transition-all duration-300 ${deletingId === s.id ? 'opacity-0 scale-95' : 'opacity-100 scale-100'}`}>
              {index < 3 && filterDevice === 'All' && (
                <div className="absolute top-0 right-0 bg-yellow-500 text-black text-[10px] font-black px-3 py-1 rounded-bl-lg z-10 uppercase tracking-widest">
                  Top #{index+1}
                </div>
              )}
              <CardHeader className="pb-3 border-b border-border/50 bg-black/20 flex flex-row items-start justify-between space-y-0">
                <div className="space-y-1">
                  <CardTitle className="text-lg line-clamp-1">{s.title}</CardTitle>
                  <CardDescription className="flex items-center gap-2">
                    <Badge variant="outline" className="text-[10px]">{s.deviceType}</Badge>
                  </CardDescription>
                </div>
                <DropdownMenu>
                  <DropdownMenuTrigger className="inline-flex shrink-0 items-center justify-center rounded-lg border border-transparent bg-clip-padding text-sm font-medium whitespace-nowrap transition-all outline-none select-none hover:bg-muted focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 disabled:pointer-events-none disabled:opacity-50 size-8">
                    <span className="sr-only">Open menu</span>
                    <MoreVertical className="h-4 w-4" />
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="bg-[#0a0a0c] border-white/10">
                    <DropdownMenuItem onSelect={() => copyToClipboard(s.code, 'Sensitivity')} className="cursor-pointer">
                      <Copy className="mr-2 h-4 w-4" />
                      <span>Copy Code</span>
                    </DropdownMenuItem>
                    {user?.uid === s.authorId && (
                      <DropdownMenuItem 
                        onSelect={(e) => { e.preventDefault(); handleDelete(s.id); }} 
                        onClick={(e) => { e.preventDefault(); e.stopPropagation(); handleDelete(s.id); }}
                        className="cursor-pointer text-red-500 focus:bg-red-500/10 focus:text-red-500"
                      >
                        <Trash2 className="mr-2 h-4 w-4" />
                        <span>Delete</span>
                      </DropdownMenuItem>
                    )}
                  </DropdownMenuContent>
                </DropdownMenu>
              </CardHeader>
              <CardContent className="pt-4 space-y-4 text-sm">
                
                <div className="space-y-3">
                  <div className="space-y-1">
                    <div className="flex justify-between items-center text-xs text-muted-foreground">
                      <span>Sensitivity Code</span>
                    </div>
                    <div className="bg-background border border-border p-2 rounded text-xs font-mono truncate select-all">
                      {s.code}
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="pt-2 pb-4 flex justify-between items-center">
                <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-red-500 hover:bg-red-500/10 transition-colors" onClick={() => handleLike(s.id, s)}>
                  <Heart className={`w-5 h-5 mr-1 ${s.likedBy?.includes(user?.uid || '') ? 'fill-red-500 text-red-500' : ''}`} /> {s.likes}
                </Button>
                <span className="text-[10px] text-muted-foreground opacity-50">Author: {s.authorId.substring(0,6)}...</span>
              </CardFooter>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}
