export type Tier = 'Bronze' | 'Silver' | 'Gold' | 'Platinum' | 'Diamond' | 'Crown' | 'Ace' | 'Ace Master' | 'Ace Dominator' | 'Conqueror';
export type PlayStyle = 'Rush' | 'Sniper' | 'Support' | 'IGL' | 'Assaulter';
export type DeviceType = 'Low-end' | 'Mid-range' | 'High-end (iPhone/iPad)' | 'Desktop/Emulator';

export interface UserProfile {
  id: string; // auth uid
  username: string;
  bgmiId: string;
  tier: Tier | string;
  kdRatio: string;
  playStyle: PlayStyle | string;
  device: DeviceType | string;
  isGyro: boolean;
  reputation: number;
  totalMatches?: number;
  matchesWon?: number;
  matchesLost?: number;
  eloRating?: number;
  winStreak?: number;
  badges?: string[];
  teamFinderActive?: boolean;
  bio?: string;
  createdAt: number;
}

export interface Match {
  id: string;
  hostId: string;
  type: '1v1' | '2v2' | 'Squad';
  status: 'Waiting' | 'Full' | 'Started' | 'Finished' | 'Disputed';
  maxPlayers: number;
  players: string[]; // user IDs
  minTier: string;
  weapon: string;
  hostResult?: 'Win' | 'Loss';
  guestResult?: 'Win' | 'Loss';
  createdAt: number;
}

export interface Message {
  id: string;
  senderId: string;
  text: string;
  createdAt: number;
}

export interface Sensitivity {
  id: string;
  authorId: string;
  title: string;
  deviceType: string;
  code: string;
  likedBy?: string[];
  likes: number;
  createdAt: number;
}

export interface TeamPost {
  id: string;
  authorId: string;
  roleNeeded: string;
  minKd: string;
  minTier: string;
  playStyle: string;
  mode: string;
  message: string;
  status: 'Open' | 'Closed';
  createdAt: number;
}

export interface TeamRequest {
  id: string;
  postId: string;
  requesterId: string;
  status: 'Pending' | 'Accepted' | 'Rejected';
  createdAt: number;
}
