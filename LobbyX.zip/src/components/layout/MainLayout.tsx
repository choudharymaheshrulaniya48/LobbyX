import { Outlet, Link, useLocation, useNavigate } from 'react-router-dom';
import { Gamepad2, Settings2, UserCircle, Users, LogOut, Info, Mail, History } from 'lucide-react';
import { useAuthStore } from '../../store/useAuthStore';
import { auth } from '../../services/firebase';
import { signOut } from 'firebase/auth';
import { LobbyXLogo } from '../LobbyXLogo';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '../ui/dropdown-menu';

export default function MainLayout() {
  const location = useLocation();
  const navigate = useNavigate();
  const { profile } = useAuthStore();

  const handleLogout = async () => {
    await signOut(auth);
  };

  const navItems = [
    { name: 'Home', path: '/' },
    { name: 'Matches', path: '/matches' },
    { name: 'Team Finder', path: '/team-finder' },
    { name: 'Sensitivity', path: '/sensitivities' },
  ];

  return (
    <div className="min-h-screen bg-[#0D0D0D] text-[#e2e8f0] font-sans flex flex-col">
      {/* Top Navbar */}
      <nav className="sticky top-0 z-50 w-full bg-[#0D0D0D]/80 backdrop-blur-md border-b border-white/5">
        <div className="max-w-7xl mx-auto px-4 md:px-8 h-20 flex items-center justify-between">
          
          {/* Logo Section */}
          <Link to="/" className="flex items-center gap-3 group">
            <LobbyXLogo className="w-12 h-12 transition-transform duration-500 group-hover:scale-105" />
            <h1 className="text-2xl font-black uppercase tracking-widest text-white">
              Lobby<span className="text-[#FF2E2E] drop-shadow-[0_0_10px_rgba(255,46,46,0.6)]">X</span>
            </h1>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex flex-1 items-center justify-end gap-10">
            {navItems.map((item) => {
              const isActive = location.pathname === item.path || (item.path !== '/' && location.pathname.startsWith(item.path));
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  className={`text-xs uppercase tracking-widest font-bold transition-all duration-300 relative px-2 py-1 ${
                    isActive ? 'text-white' : 'text-gray-400 hover:text-white'
                  }`}
                >
                  {item.name}
                  {isActive ? (
                    <span className="absolute -bottom-2 left-0 right-0 h-[2px] bg-[#FF2E2E] shadow-[0_0_12px_rgba(255,46,46,0.9)] rounded-t-full" />
                  ) : (
                    <span className="absolute -bottom-2 left-0 right-0 h-[2px] bg-[#FF2E2E] shadow-[0_0_12px_rgba(255,46,46,0.9)] rounded-t-full scale-x-0 opacity-0 group-hover:scale-x-100 group-hover:opacity-100 transition-all duration-300" />
                  )}
                </Link>
              );
            })}

            <div className="flex items-center gap-4 ml-6 border-l border-white/10 pl-6">
              <div className="flex flex-col flex-1 items-end">
                <span className="text-xs font-bold text-white capitalize leading-tight">{profile?.username || 'Player'}</span>
                <span className="text-[10px] text-[#FF2E2E] font-black uppercase tracking-widest leading-tight">{profile?.tier || 'Unranked'}</span>
              </div>
              
              <DropdownMenu>
                <DropdownMenuTrigger render={
                  <button 
                    className="w-10 h-10 rounded-full border border-white/10 hover:border-[#FF2E2E]/50 overflow-hidden bg-[#1A1A1A] flex items-center justify-center transition-colors group shadow-[0_0_15px_rgba(0,0,0,0.5)] hover:shadow-[0_0_20px_rgba(255,46,46,0.3)]"
                    title="Menu"
                  >
                    <span className="font-bold text-sm text-white group-hover:text-[#FF2E2E] transition-colors">{profile?.username?.charAt(0).toUpperCase() || 'U'}</span>
                  </button>
                } />
                <DropdownMenuContent align="end" className="w-56 glass bg-[#0a0a0c] border-white/10 mt-2 p-2">
                  <DropdownMenuItem onClick={() => navigate('/profile?tab=info')} className="cursor-pointer text-gray-300 hover:text-white hover:bg-white/5 focus:bg-white/5 font-bold text-xs uppercase tracking-widest py-3">
                    <UserCircle className="w-4 h-4 mr-3 text-[#FF2E2E]" />
                    Profile Info
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => navigate('/profile?tab=edit')} className="cursor-pointer text-gray-300 hover:text-white hover:bg-white/5 focus:bg-white/5 font-bold text-xs uppercase tracking-widest py-3">
                    <Settings2 className="w-4 h-4 mr-3 text-[#FF2E2E]" />
                    Edit Profile
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => navigate('/profile?tab=history')} className="cursor-pointer text-gray-300 hover:text-white hover:bg-white/5 focus:bg-white/5 font-bold text-xs uppercase tracking-widest py-3">
                    <History className="w-4 h-4 mr-3 text-[#FF2E2E]" />
                    Match History
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => navigate('/profile?tab=about')} className="cursor-pointer text-gray-300 hover:text-white hover:bg-white/5 focus:bg-white/5 font-bold text-xs uppercase tracking-widest py-3">
                    <Info className="w-4 h-4 mr-3 text-[#FF2E2E]" />
                    About Let's Play
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => navigate('/profile?tab=contact')} className="cursor-pointer text-gray-300 hover:text-white hover:bg-white/5 focus:bg-white/5 font-bold text-xs uppercase tracking-widest py-3">
                    <Mail className="w-4 h-4 mr-3 text-[#FF2E2E]" />
                    Contact Us
                  </DropdownMenuItem>
                  <DropdownMenuSeparator className="bg-white/10 my-2" />
                  <DropdownMenuItem onClick={handleLogout} className="cursor-pointer text-[#FF2E2E] hover:text-[#FF2E2E]/90 hover:bg-red-500/10 focus:bg-red-500/10 font-bold text-xs uppercase tracking-widest py-3">
                    <LogOut className="w-4 h-4 mr-3" />
                    Sign Out
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>

          {/* Mobile Profile/Menu */}
          <div className="md:hidden flex items-center gap-4">
            <DropdownMenu>
              <DropdownMenuTrigger render={
                <button 
                  className="w-9 h-9 rounded-full border border-white/10 hover:border-[#FF2E2E]/50 overflow-hidden bg-[#1A1A1A] flex items-center justify-center transition-colors shadow-[0_0_15px_rgba(0,0,0,0.5)]"
                  title="Menu"
                >
                  <span className="font-bold text-xs text-white uppercase">{profile?.username?.charAt(0) || 'U'}</span>
                </button>
              } />
              <DropdownMenuContent align="end" className="w-56 glass bg-[#0a0a0c] border-white/10 mt-2 p-2 relative z-[60]">
                <DropdownMenuItem onClick={() => navigate('/profile?tab=info')} className="cursor-pointer text-gray-300 hover:text-white hover:bg-white/5 focus:bg-white/5 font-bold text-xs uppercase tracking-widest py-3">
                  <UserCircle className="w-4 h-4 mr-3 text-[#FF2E2E]" />
                  Profile Info
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => navigate('/profile?tab=edit')} className="cursor-pointer text-gray-300 hover:text-white hover:bg-white/5 focus:bg-white/5 font-bold text-xs uppercase tracking-widest py-3">
                  <Settings2 className="w-4 h-4 mr-3 text-[#FF2E2E]" />
                  Edit Profile
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => navigate('/profile?tab=history')} className="cursor-pointer text-gray-300 hover:text-white hover:bg-white/5 focus:bg-white/5 font-bold text-xs uppercase tracking-widest py-3">
                  <History className="w-4 h-4 mr-3 text-[#FF2E2E]" />
                  Match History
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => navigate('/profile?tab=about')} className="cursor-pointer text-gray-300 hover:text-white hover:bg-white/5 focus:bg-white/5 font-bold text-xs uppercase tracking-widest py-3">
                  <Info className="w-4 h-4 mr-3 text-[#FF2E2E]" />
                  About Let's Play
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => navigate('/profile?tab=contact')} className="cursor-pointer text-gray-300 hover:text-white hover:bg-white/5 focus:bg-white/5 font-bold text-xs uppercase tracking-widest py-3">
                  <Mail className="w-4 h-4 mr-3 text-[#FF2E2E]" />
                  Contact Us
                </DropdownMenuItem>
                <DropdownMenuSeparator className="bg-white/10 my-2" />
                <DropdownMenuItem onClick={handleLogout} className="cursor-pointer text-[#FF2E2E] hover:text-[#FF2E2E]/90 hover:bg-red-500/10 focus:bg-red-500/10 font-bold text-xs uppercase tracking-widest py-3">
                  <LogOut className="w-4 h-4 mr-3" />
                  Sign Out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </nav>

      {/* Mobile Sticky Bottom Nav */}
      <nav className="md:hidden fixed bottom-0 w-full bg-[#0D0D0D]/90 backdrop-blur-md border-t border-white/5 z-50">
        <div className="flex justify-around items-center h-16">
          {navItems.map((item) => {
            const isActive = location.pathname === item.path || (item.path !== '/' && location.pathname.startsWith(item.path));
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`flex flex-col items-center justify-center w-full h-full space-y-1 relative ${
                  isActive ? 'text-[#FF2E2E]' : 'text-gray-500 hover:text-white'
                }`}
              >
                <span className={`text-[10px] uppercase tracking-widest font-bold ${isActive ? 'drop-shadow-[0_0_8px_rgba(255,46,46,0.6)]' : ''}`}>{item.name}</span>
                {isActive && <span className="absolute bottom-1 w-1 h-1 rounded-full bg-[#FF2E2E] shadow-[0_0_8px_rgba(255,46,46,0.9)]" />}
              </Link>
            );
          })}
        </div>
      </nav>

      <main className="flex-1 w-full p-4 md:p-8 pb-24 md:pb-8 flex flex-col">
        <div className="container max-w-6xl mx-auto flex-1 animate-in fade-in zoom-in-95 duration-500">
          <Outlet />
        </div>
      </main>
    </div>
  );
}
