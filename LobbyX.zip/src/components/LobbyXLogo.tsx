import React from 'react';

export function LobbyXLogo({ className = "w-12 h-12" }: { className?: string }) {
  return (
    <div className={`relative flex items-center justify-center ${className}`}>
      <svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full overflow-visible">
        <defs>
          <filter id="neon-glow" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur stdDeviation="4" result="blur1" />
            <feGaussianBlur stdDeviation="8" result="blur2" />
            <feMerge>
              <feMergeNode in="blur2" />
              <feMergeNode in="blur1" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>
        {/* 'L' monogram */}
        <path 
          d="M25 20 V80 H55" 
          stroke="#FFFFFF" 
          strokeWidth="12" 
          strokeLinecap="square" 
          strokeLinejoin="miter" 
        />
        {/* 'X' monogram with Neon Red Glow */}
        <path 
          d="M45 20 L85 80 M85 20 L45 80" 
          stroke="#FF2E2E" 
          strokeWidth="12" 
          strokeLinecap="round" 
          filter="url(#neon-glow)" 
        />
      </svg>
    </div>
  );
}
